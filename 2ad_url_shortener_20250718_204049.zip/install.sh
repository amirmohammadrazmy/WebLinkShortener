#!/bin/bash
echo "Installing 2ad.ir URL Shortener..."
echo
echo "Installing Python dependencies..."
pip install selenium webdriver-manager
echo
echo "Installation complete!"
echo
echo "To run the program:"
echo "  python run_local.py"
echo
echo "OR:"
echo "  python main.py --username your_email@example.com --password your_password"
echo
